import bangundatar

bangundatar.l_persegi(2)
bangundatar.l_lingkaran(4)
bangundatar.l_jajargenjang(6, 7)
bangundatar.l_persegipanjang(8, 9)
bangundatar.l_segitiga(10, 11)

import bangunruang

bangunruang.l_kubus(10)
bangunruang.l_balok(8, 9, 7)
bangunruang.l_prisma(5, 12)
bangunruang.l_limas(14, 20)
bangunruang.l_tabung(15, 21)
bangunruang.l_kerucut(16, 17)
bangunruang.l_bola(25)

import hitung

hitung.tambah(1, 2)
hitung.kurang(3, 4)
hitung.kali(5, 6)
hitung.bagi(7, 8)
hitung.pangkat(9, 10)