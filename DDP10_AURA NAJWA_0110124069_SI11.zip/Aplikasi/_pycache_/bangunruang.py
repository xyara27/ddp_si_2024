import math

def l_kubus(s):
    hitung = s ** 2
    print (f"luas kubus adalah {hitung}")

def l_balok(panjang, lebar, tinggi):
    hitung = 2 * panjang * lebar * tinggi
    print (f"luas balok adalah {hitung}")

def l_prisma(keliling_alas, tinggi):
    hitung = keliling_alas * tinggi
    print (f"luas prima adalah {hitung}")

def l_limas(L_alas, L_sisi_tegak):
    hitung = L_alas + L_sisi_tegak
    print (f"luas limus adalah {hitung}")

def l_tabung(r, t):
    hitung = 2 * 3.14 * r * (r + t)
    print (f"luas tabung adalah {hitung}")

def l_kerucut(r, s):
    hitung = math.pi * r * (r + s)
    print (f"luas kerucut adalah {hitung}")

def l_bola(r):
    hitung = 4 * 3.14 * r **2
    print (f"luas bola adalah {hitung}")