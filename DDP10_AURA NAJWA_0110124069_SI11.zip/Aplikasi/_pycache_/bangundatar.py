import math

def l_persegi(sisi):
    hitung = sisi * sisi
    print(f"luas persegi adalah {hitung}")

def l_lingkaran(r):
    hitung = r * 3.14 * r
    print(f"luas lingkaran adalah {hitung}")  

def l_jajargenjang(alas, tinggi):
    hitung = alas * tinggi
    print(f"luas jajargenjang adalah {hitung}")

def l_persegipanjang(panjang, lebar):
    hitung = panjang * lebar
    print(f"luas persegipanjang adalah {hitung}")

def l_segitiga(alas, tinggi):
    hitung = alas * tinggi
    print(f"luas segitiga adalah {hitung}")